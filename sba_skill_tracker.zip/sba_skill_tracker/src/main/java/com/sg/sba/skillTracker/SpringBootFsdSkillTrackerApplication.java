package com.sg.sba.skillTracker;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootFsdSkillTrackerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootFsdSkillTrackerApplication.class, args);
	}
}
