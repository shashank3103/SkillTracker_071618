/**
 * 
 */
package com.sg.sba.skillTracker.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.sg.sba.skillTracker.dto.Skill;

/**
 * @author Shashank Gunthey
 *
 */

@Repository
public interface ISkillDAO extends JpaRepository<Skill, Long> {

}
