/**
 * 
 */
package com.sg.sba.skillTracker.service;

import java.util.List;

import com.sg.sba.skillTracker.dto.AssociateSkill;


/**
 * @author Shashank
 *
 */
public interface IAssociateSkillService {
	
	List<Object[]> getCountBySkill();
	
	List<AssociateSkill> getAssociateSkillsBySkillId(Long skillId);

}
