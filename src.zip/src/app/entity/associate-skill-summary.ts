export class AssociateSkillSummary {
    public skillName : string;
    public associateCount : number;
}
