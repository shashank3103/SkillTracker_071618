export class DashboardSummary {
    public malePercentage : number;
    public femalePercentage : number;
    public levelOnePercentage : number;
    public levelTwoPercentage : number;
    public levelThreePercentage : number;
}
