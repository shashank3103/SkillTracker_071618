import { Injectable } from '@angular/core';
import { Headers, Http, RequestOptions, RequestMethod } from '@angular/http';
import { map, catchError } from 'rxjs/operators';

@Injectable()
export class DashboardService {

  url : string;
  
  constructor(private http : Http) {
    //this.url = environment.stBaseAPIUrl + 'asSummary/';
    this.url = 'http://localhost:8888/' + 'asSummary/';
   }
   
  getAssociateSkillList(){
    return this.http.get(this.url).pipe(map(res => res.json()));
  }

  getAssociateSkillsById(skillId : number){
    let cpHeaders = new Headers({ 'Content-Type': 'application/json' });
    let options = new RequestOptions({ headers: cpHeaders });
    return this.http.get(this.url + skillId, options)
      .pipe(map(res => res.json()));
  }

}
