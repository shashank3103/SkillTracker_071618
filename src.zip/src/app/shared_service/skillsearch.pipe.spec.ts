import { SkillsearchPipe } from './skillsearch.pipe';

describe('SkillsearchPipe', () => {
  it('create an instance', () => {
    const pipe = new SkillsearchPipe();
    expect(pipe).toBeTruthy();
  });
});
