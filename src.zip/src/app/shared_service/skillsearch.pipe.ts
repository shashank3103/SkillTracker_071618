import { Pipe, PipeTransform } from '@angular/core';
import { Skill } from '../entity/skill';

@Pipe({
  name: 'skillsearch'
})
export class SkillsearchPipe implements PipeTransform {

  // transform(value: any, args?: any): any {
  //   return null;
  // }

  transform(value : any[], assocSkill : string ) {
    
     if (value && value.length){
       return value.filter(item =>{
           if (assocSkill && (item.skillName != null) && item.skillName.toLowerCase().indexOf(assocSkill.toLowerCase()) === -1){
               return false;
           }
           return true;
      })
     }
     else{
       return value;
     }

   }

  // transform(skills: any, term: any): any {
    
  //   //check if search term is undefined
  //   console.log(term);
  //   if(term == undefined) return skills;

  //   return skills.filter(function(skill: Skill){
  //     return skill.skillName.toLowerCase().startsWith(term.toLowerCase());
  //   })
  // }

}
